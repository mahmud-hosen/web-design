### Simple navbar slider / scroll for bootstrap 4 (alpha 6).
- fixed navbar (top right)
- updates & highlights current section in view
- click to scroll to section
- updates on scroll

### Example
[Codepen.io Example](http://codepen.io/ts-de/pen/OpPYrw)

### Usage
See index.html

##### Simply add:
```html
<link rel="stylesheet" href="./navbar-fixed.css">
<script src="./navbar-fixed.js"></script>
```
