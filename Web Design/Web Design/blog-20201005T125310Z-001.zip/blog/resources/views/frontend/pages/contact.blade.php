@extends('frontend.layouts.master')


@section('content')


<h1>Mahmud</h1>




@endsection
