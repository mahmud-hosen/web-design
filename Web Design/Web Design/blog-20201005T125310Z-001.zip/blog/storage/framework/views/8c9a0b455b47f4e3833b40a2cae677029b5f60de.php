 <script src="<?php echo e(asset('jquery-3.2.1.slim.min.js')); ?>" ></script>
  <script src="<?php echo e(asset('popper.min.js')); ?>" ></script>
  <script src="<?php echo e(asset('bootstrap.min.js')); ?>" ></script>


<?php /**PATH C:\xampp\htdocs\blog\resources\views/partials/scripts.blade.php ENDPATH**/ ?>