
 <!---footer start-->

 <footer class="bottom-container"> 
            
            
            <a href=" ">Facebook </a>
            <a href=" ">Youtube</a>
            <a href=" ">Website</a>
            <p> Copyright @copy; Mahmud 2020</p>
    
        </footer>

  <!---footer end--><?php /**PATH C:\xampp\htdocs\blog\resources\views/partials/footer.blade.php ENDPATH**/ ?>