
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
    <button type="button" class="close" data-dismiss="alert">&times;</button>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<?php if(Session::has('success')): ?>
  <div class="alert alert-success">
  <p><?php echo e(Session::get('success')); ?></p>
  
  </div>

  <?php endif; ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/backend/partials/messages.blade.php ENDPATH**/ ?>