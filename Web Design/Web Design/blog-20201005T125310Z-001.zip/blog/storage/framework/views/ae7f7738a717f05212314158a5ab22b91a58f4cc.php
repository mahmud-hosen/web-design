


<?php $__env->startSection('content'); ?>


<h1>Mahmud</h1>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/frontend/pages/contact.blade.php ENDPATH**/ ?>