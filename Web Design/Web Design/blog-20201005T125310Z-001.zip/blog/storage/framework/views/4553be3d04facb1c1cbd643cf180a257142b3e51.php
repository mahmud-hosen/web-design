
             <div class="list-group">
             <a href="#" class="list-group-item active">First item</a>
             <a href="#" class="list-group-item">Second item</a>
             <a href="#" class="list-group-item">Third item</a>
             <a href="#" class="list-group-item">Third item</a>
             <a href="#" class="list-group-item">Third item</a>
             <a href="#" class="list-group-item">Third item</a>
             </div><?php /**PATH C:\xampp\htdocs\blog\resources\views/partials/products_sidebar.blade.php ENDPATH**/ ?>