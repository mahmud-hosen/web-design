

<?php $__env->startSection('content'); ?>
<div class="main-panel">
      <div class="content-wrapper">
        
        <div class="card">
               <div class="card-header">
               Edit Product

               </div>
           <div class="card-body">
                
              <form  action="<?php echo e(route('admin.product.update',$product->id)); ?>" method="post" enctype="multipart/form-data" >
                     <?php echo e(csrf_field()); ?>


                     <?php echo $__env->make('backend.partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 

                      <div class="form-group">
                             <label for="exampleInputEmail1">Title</label>
                             <input type="text" class="form-control" name="title" id="title" aria-describedby="emailHelp" value="<?php echo e($product->title); ?>">
                      </div>
                      <div class="form-group">
                              <label for="exampleInputPassword1">Description</label>
                              <textarea name="description" class="form-control" cols="80" rows="8"  >"<?php echo e($product->description); ?>"</textarea>
                      </div>


                      <div class="form-group">
                             <label for="exampleInputEmail1">Price</label>
                             <input type="number" class="form-control" name="price" id="price" aria-describedby="emailHelp" value="<?php echo e($product->price); ?>">
                      </div>

                      <div class="form-group">
                             <label for="exampleInputEmail1">Quantity</label>
                             <input type="number" class="form-control" name="quantity" id="quantity" aria-describedby="emailHelp" value="<?php echo e($product->quantity); ?>">
                      
                      </div>







                      
                      <div class="form-group">
                             <label for="exampleInputEmail1">Select Category</label>
                             <select name="category_id" class="form-control">
                             <option value="" >Please select a category for the product</option>
                                 <?php $__currentLoopData = App\Models\Category::orderBY('name', 'asc')->where('parent_id',NUll)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($parent->id); ?>" <?php echo e($parent->id== $product->category->id ? 'selected': ''); ?>    ><?php echo e($parent->name); ?></option>  

                                          <?php $__currentLoopData = App\Models\Category::orderBY('name', 'asc')->where('parent_id', $parent->id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                              <option value="<?php echo e($child->id); ?>" <?php echo e($child->id == $product->category->id ? 'selected': ''); ?> > ------> <?php echo e($child->name); ?></option>  
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                             </select>
                      </div>










                      <div class="form-group">
                             <label for="exampleInputEmail1">Select Brand</label>
                             <select name="brand_id" class="form-control">
                             <option value="" >Please select a brand for the product</option>
                                 <?php $__currentLoopData = App\Models\Brand::orderBY('name', 'asc')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $br): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($br->id); ?>" <?php echo e($br->id == $product->brand->id ? 'selected' : ''); ?> ><?php echo e($br->name); ?></option>  

       
                                          
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                             </select>
                      </div>















                      


                      <div class="form-group">
                             <label for="exampleInputEmail1">admin_id</label>
                             <input type="number" class="form-control" name="admin_id" id="admin_id" aria-describedby="emailHelp" value="<?php echo e($product->admin_id); ?>">
                      </div>
                      


                      <div class="form-group">
                             <label for="exampleInputEmail1">Product Image</label>
                             
                             <div class="row">
                             
                             <div class="col-md-4">
                             <input type="file" class="form-control" name="product_image[]" id="product_image" >
                             </div>


                             <div class="col-md-4">
                             <input type="file" class="form-control" name="product_image[]" id="product_image" >
                             </div>


                             <div class="col-md-4">
                             <input type="file" class="form-control" name="product_image[]" id="product_image" >
                             </div>

                           
                        
                             
                             </div>

                      </div>











                   <button type="submit" class="btn btn-primary">Update Product</button>
              </form>


      

                
         
           </div>

         </div>

      </div>   
</div>
      <!-- main-panel ends -->
<?php $__env->stopSection(); ?>
















      
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/backend/pages/product/edit.blade.php ENDPATH**/ ?>